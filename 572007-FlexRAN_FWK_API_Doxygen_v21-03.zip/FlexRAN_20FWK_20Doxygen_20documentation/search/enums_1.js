var searchData=
[
  ['coreusageperttistats',['CoreUsagePerTtiStats',['../ebbu__pool__thread_8h.html#afef3102983c33ec13329e931bde56b52',1,'ebbu_pool_thread.h']]],
  ['coreusagestats',['CoreUsageStats',['../ebbu__pool__thread_8h.html#a33913e5e593f59fc159f6206affcf96c',1,'ebbu_pool_thread.h']]]
];
