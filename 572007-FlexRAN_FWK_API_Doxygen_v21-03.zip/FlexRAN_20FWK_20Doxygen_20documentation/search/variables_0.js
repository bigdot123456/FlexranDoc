var searchData=
[
  ['activeperiodidx',['activePeriodIdx',['../structbbupool__cell__info.html#a30e91f7646d1343229f4f79962523293',1,'bbupool_cell_info::activePeriodIdx()'],['../structbbupool__multicell__info.html#a5141a984cebac179f2a28b92a40f3daf',1,'bbupool_multicell_info::activePeriodIdx()']]],
  ['activesfn',['activeSfn',['../structbbupool__cell__info.html#ad4bb9c6ebb4ffa3b9cceac1e3e63a475',1,'bbupool_cell_info::activeSfn()'],['../structbbupool__multicell__info.html#a470b4090615555b917eff86ad70f4676',1,'bbupool_multicell_info::activeSfn()']]],
  ['affinitytasklist',['affinityTaskList',['../struct_b_b_u_p_o_o_l___c_o_r_e___o_p___s_t_r.html#aabe8b41f79403b6ac9936225ffd6d1a7',1,'BBUPOOL_CORE_OP_STR']]]
];
