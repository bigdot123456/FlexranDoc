var searchData=
[
  ['_5f_5fattribute_5f_5f',['__attribute__',['../struct____attribute____.html',1,'__attribute__'],['../bbupool__common_8h.html#a2840d91b7c4cbf10a7b497ecebf7e399',1,'__attribute__((aligned(32))) TaskGenInfoInt:&#160;bbupool_common.h']]]
];
