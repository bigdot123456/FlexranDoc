var searchData=
[
  ['uioportnum',['uIoPortNum',['../structbbupool__io__thread__config.html#aa45b1ec653381526918cb4de97b50dc6',1,'bbupool_io_thread_config']]],
  ['uiotasknum',['uIoTaskNum',['../structbbupool__io__port__config.html#a6038513640cd136c8f11aae0a2ffe14a',1,'bbupool_io_port_config']]],
  ['uiotheadnum',['uIoTheadNum',['../structbbupool__io__api__config.html#a04684f1d4ef32daf6dd15f3e7b2d6a59',1,'bbupool_io_api_config']]],
  ['uplink',['UPLINK',['../bbupool__common_8h.html#ab518e508105cdd1cc46fb120a888b1f7a035533d604baa6f836af5b07ad47069c',1,'bbupool_common.h']]]
];
