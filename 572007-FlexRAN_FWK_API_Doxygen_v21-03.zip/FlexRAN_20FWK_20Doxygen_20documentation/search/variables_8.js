var searchData=
[
  ['queueid',['queueId',['../struct_b_b_u_p_o_o_l___c_o_r_e___o_p___s_t_r.html#a1f86790ce62db5fd043562fc8a866f20',1,'BBUPOOL_CORE_OP_STR']]],
  ['queueidx',['queueIdx',['../structbbupool__cell__info.html#a4ab0d4c25bd5ddd58d7ee7badd5d27ee',1,'bbupool_cell_info::queueIdx()'],['../structbbupool__multicell__info.html#a2c6c1797b4b177630897ecbae366c8df',1,'bbupool_multicell_info::queueIdx()']]]
];
