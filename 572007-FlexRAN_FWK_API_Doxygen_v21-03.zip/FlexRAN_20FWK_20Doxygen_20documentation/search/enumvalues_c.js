var searchData=
[
  ['task_5fbypass',['TASK_BYPASS',['../bbupool__common_8h.html#a619ea72ac0cf2d40f427a91727ce7340aced4e0bcfbc222ed2bba33bc0aebc9d3',1,'bbupool_common.h']]],
  ['task_5fexecute',['TASK_EXECUTE',['../bbupool__common_8h.html#a619ea72ac0cf2d40f427a91727ce7340ab6ea1af9430e0fe17a1971a9048c0fbc',1,'bbupool_common.h']]]
];
