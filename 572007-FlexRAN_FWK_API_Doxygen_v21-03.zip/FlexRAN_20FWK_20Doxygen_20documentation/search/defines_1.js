var searchData=
[
  ['ia_5falign',['IA_ALIGN',['../ebbu__pool__common_8h.html#aeb9447296ff092e1118766b96f97e4c7',1,'ebbu_pool_common.h']]],
  ['invalid_5fcore_5fid',['INVALID_CORE_ID',['../bbupool__macro_8h.html#aee597e8fa1f316e1615791fd05f082fe',1,'bbupool_macro.h']]],
  ['invalid_5fmax_5ftask_5fnum',['INVALID_MAX_TASK_NUM',['../bbupool__macro_8h.html#a5b85829889fd7df36e53830087d5c1cb',1,'bbupool_macro.h']]],
  ['invalid_5fpriority',['INVALID_PRIORITY',['../bbupool__macro_8h.html#a2173d8ea338962f5701a5d6f5cf33994',1,'bbupool_macro.h']]],
  ['invalid_5ftask_5fcount',['INVALID_TASK_COUNT',['../bbupool__macro_8h.html#a25300e8be6f401a7015d84d23e610a1c',1,'bbupool_macro.h']]],
  ['invalid_5ftask_5ftype',['INVALID_TASK_TYPE',['../bbupool__macro_8h.html#a94a5ed2c3c1388aa7d6f6b13a0ffaa5d',1,'bbupool_macro.h']]],
  ['invalid_5fvalue_5f16',['INVALID_VALUE_16',['../bbupool__macro_8h.html#ab271c5672bce47e19d6133f16e9bf36e',1,'bbupool_macro.h']]],
  ['invalid_5fvalue_5f32',['INVALID_VALUE_32',['../bbupool__macro_8h.html#ae21eeab75c2a709d20ff8201dcb169d9',1,'bbupool_macro.h']]]
];
