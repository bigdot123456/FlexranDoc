var indexSectionsWithContent =
{
  0: "_abcdeghilmnopqrstuwz",
  1: "_bcst",
  2: "bde",
  3: "_ber",
  4: "abceginpqstu",
  5: "bcemrst",
  6: "bcelprstw",
  7: "abcdehilmprstuw",
  8: "bimnoptz",
  9: "emprt",
  10: "beim"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

