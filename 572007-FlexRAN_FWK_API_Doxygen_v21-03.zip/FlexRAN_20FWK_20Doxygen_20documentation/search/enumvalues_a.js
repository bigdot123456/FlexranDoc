var searchData=
[
  ['record_5fall',['RECORD_ALL',['../group__group__report.html#gga35c420c848bcd446b0d124a2a1827d91a8509b33d66d164d8ffd60edaa675d2f2',1,'ebbu_pool_report.h']]],
  ['resume_5ferror_5fcore_5fnot_5fexist',['RESUME_ERROR_CORE_NOT_EXIST',['../bbupool__common_8h.html#a5af648da4aaaa32787bb86fd1fcc9b83adedb60abddfe38bd7de126988d402772',1,'bbupool_common.h']]],
  ['resume_5ferror_5fnot_5fpending',['RESUME_ERROR_NOT_PENDING',['../bbupool__common_8h.html#a5af648da4aaaa32787bb86fd1fcc9b83ae089d6b4d725c21df3c7ec6e7427db8e',1,'bbupool_common.h']]],
  ['resume_5fok',['RESUME_OK',['../bbupool__common_8h.html#a5af648da4aaaa32787bb86fd1fcc9b83abdf58491d5ae9da7348ee7134a61126d',1,'bbupool_common.h']]],
  ['rmv_5ferror_5faffinity_5fcore',['RMV_ERROR_AFFINITY_CORE',['../bbupool__common_8h.html#a5af648da4aaaa32787bb86fd1fcc9b83a609435664fd10653eec956aceceeaa27',1,'bbupool_common.h']]],
  ['rmv_5ferror_5fcore_5fnot_5fexist',['RMV_ERROR_CORE_NOT_EXIST',['../bbupool__common_8h.html#a5af648da4aaaa32787bb86fd1fcc9b83ae0d0d91d520b52489065034e5883c750',1,'bbupool_common.h']]],
  ['rmv_5ferror_5flast_5fcore',['RMV_ERROR_LAST_CORE',['../bbupool__common_8h.html#a5af648da4aaaa32787bb86fd1fcc9b83a78843e105f308558d0c4849375ab60ef',1,'bbupool_common.h']]],
  ['rmv_5fok',['RMV_OK',['../bbupool__common_8h.html#a5af648da4aaaa32787bb86fd1fcc9b83a59557f18350aee8844511a1ec1a8903a',1,'bbupool_common.h']]],
  ['rt_5fthread_5fhalt',['RT_THREAD_HALT',['../bbupool__common_8h.html#ad3859a50c58987d1e1082310df3ae235a046f307702cd3c6bd9599da5addc71a1',1,'bbupool_common.h']]],
  ['rt_5fthread_5frun',['RT_THREAD_RUN',['../bbupool__common_8h.html#ad3859a50c58987d1e1082310df3ae235ac05842510c0bfdb664b89634e2f54cb3',1,'bbupool_common.h']]],
  ['rt_5fthread_5fstop',['RT_THREAD_STOP',['../bbupool__common_8h.html#ad3859a50c58987d1e1082310df3ae235ad093ae22a3ffb9a5acb18d97b0269ea8',1,'bbupool_common.h']]]
];
