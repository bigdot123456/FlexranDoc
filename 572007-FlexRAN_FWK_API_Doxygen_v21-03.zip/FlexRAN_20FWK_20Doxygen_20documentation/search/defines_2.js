var searchData=
[
  ['max_5fcores_5fper_5ftask',['MAX_CORES_PER_TASK',['../bbupool__macro_8h.html#a118497273afbafa258fb985c25cbe6af',1,'bbupool_macro.h']]],
  ['max_5fframe_5fnum_5fref',['MAX_FRAME_NUM_REF',['../bbupool__macro_8h.html#a3b3a48fddfc36515bc8b12ab4a657ada',1,'bbupool_macro.h']]],
  ['max_5fio_5fport',['MAX_IO_PORT',['../bbupool__macro_8h.html#a1d88e6d1d93bea60441d4bd51530031a',1,'bbupool_macro.h']]],
  ['max_5fio_5ftask_5fper_5fport',['MAX_IO_TASK_PER_PORT',['../bbupool__macro_8h.html#a664be5c32fae7b842e435b55e6115cfc',1,'bbupool_macro.h']]],
  ['max_5fio_5fthred',['MAX_IO_THRED',['../bbupool__macro_8h.html#a5caa81d397d3b6c572556f95c89bf0bd',1,'bbupool_macro.h']]],
  ['max_5fname_5flength',['MAX_NAME_LENGTH',['../bbupool__macro_8h.html#a0c397a708cec89c74029582574516b30',1,'bbupool_macro.h']]],
  ['max_5fnext_5ftask_5fnr',['MAX_NEXT_TASK_NR',['../bbupool__macro_8h.html#abb6e4e94a6d3babd693010d56abbf14a',1,'bbupool_macro.h']]],
  ['max_5fsplit_5fnum',['MAX_SPLIT_NUM',['../bbupool__cfg_8h.html#aa1188582efedcb1087c96ab08a6a125d',1,'bbupool_cfg.h']]],
  ['max_5fta_5fsf',['MAX_TA_SF',['../bbupool__macro_8h.html#ade15f04ef50ad241a62f3c5bb3031407',1,'bbupool_macro.h']]],
  ['max_5ftask_5fsplit_5fnum',['MAX_TASK_SPLIT_NUM',['../bbupool__macro_8h.html#a359160a2ac1f74190d32fbd9019c0c7a',1,'bbupool_macro.h']]]
];
