var searchData=
[
  ['bbupool_5fmaxperiodlen_5fcfg',['bbupool_maxPeriodLen_cfg',['../bbupool__api_8h.html#a5523f4661c8a8ad8ff894b31c885ee8a',1,'bbupool_api.h']]],
  ['bbupool_5fmultitaskgroup_5factive',['bbupool_multiTaskGroup_active',['../bbupool__api_8h.html#a66acd13a0c36e2fda534ca12c71e5d96',1,'bbupool_api.h']]],
  ['bbupool_5fmultitaskgroup_5fdeactive',['bbupool_multiTaskGroup_deactive',['../bbupool__api_8h.html#aeb6f74b6d8639dc8ff5044cfd5ba1537',1,'bbupool_api.h']]],
  ['bbupool_5fperiod_5fbypasstask',['bbupool_period_bypassTask',['../bbupool__api_8h.html#a982402af3d3e51e19e6fd8b13caa3f2e',1,'bbupool_api.h']]],
  ['bbupool_5fperiodidx_5fupdate',['bbupool_periodIdx_update',['../bbupool__api_8h.html#a0cf130b2404ea75743812bc28e32049b',1,'bbupool_api.h']]],
  ['bbupool_5fskip_5ftask_5fruncnt',['BBUPOOL_SKIP_TASK_RUNCNT',['../bbupool__macro_8h.html#a5e20fe0e7a425f484ea050decc18d7bf',1,'bbupool_macro.h']]],
  ['bbupool_5ftaskgroup_5factive',['bbupool_taskGroup_active',['../bbupool__api_8h.html#a2050bd55c86a6c698618c2a48b8ad4e4',1,'bbupool_api.h']]],
  ['bbupool_5ftaskgroup_5fdeactive',['bbupool_taskGroup_deactive',['../bbupool__api_8h.html#a25d18267c1fffb3d3b92147b73c3ebc0',1,'bbupool_api.h']]],
  ['bbupool_5fversion_5fstring_5fmax_5flen',['BBUPOOL_VERSION_STRING_MAX_LEN',['../bbupool__common_8h.html#ae6af1cc95552e1104a3ae3871e9cb184',1,'bbupool_common.h']]]
];
