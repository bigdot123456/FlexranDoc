var searchData=
[
  ['pool_5fscheduler',['POOL_SCHEDULER',['../bbupool__macro_8h.html#a86e04a7432ec21d6290e770eb8463c80',1,'bbupool_macro.h']]],
  ['pool_5ftask_5fgenerator',['POOL_TASK_GENERATOR',['../bbupool__macro_8h.html#a682a7a8d8bbe06ce20dda017cf7c1297',1,'bbupool_macro.h']]]
];
