var searchData=
[
  ['events_20_2f_20tasks',['Events / Tasks',['../group__group__event.html',1,'']]]
];
