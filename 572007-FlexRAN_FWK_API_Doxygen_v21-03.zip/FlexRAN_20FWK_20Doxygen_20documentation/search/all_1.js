var searchData=
[
  ['activeperiodidx',['activePeriodIdx',['../structbbupool__cell__info.html#a30e91f7646d1343229f4f79962523293',1,'bbupool_cell_info::activePeriodIdx()'],['../structbbupool__multicell__info.html#a5141a984cebac179f2a28b92a40f3daf',1,'bbupool_multicell_info::activePeriodIdx()']]],
  ['activesfn',['activeSfn',['../structbbupool__cell__info.html#ad4bb9c6ebb4ffa3b9cceac1e3e63a475',1,'bbupool_cell_info::activeSfn()'],['../structbbupool__multicell__info.html#a470b4090615555b917eff86ad70f4676',1,'bbupool_multicell_info::activeSfn()']]],
  ['add_5ferror_5fduplt_5fcore',['ADD_ERROR_DUPLT_CORE',['../bbupool__common_8h.html#a5af648da4aaaa32787bb86fd1fcc9b83a9b8f312a1bba468ef4b51fc30f92e96e',1,'bbupool_common.h']]],
  ['add_5ferror_5fqueue_5fnot_5fexist',['ADD_ERROR_QUEUE_NOT_EXIST',['../bbupool__common_8h.html#a5af648da4aaaa32787bb86fd1fcc9b83a0a955065d241f61e19db72bb4c647a68',1,'bbupool_common.h']]],
  ['add_5fok',['ADD_OK',['../bbupool__common_8h.html#a5af648da4aaaa32787bb86fd1fcc9b83a0a44efbc1e561a7bd0856b4af4e1e7b4',1,'bbupool_common.h']]],
  ['affinitytasklist',['affinityTaskList',['../struct_b_b_u_p_o_o_l___c_o_r_e___o_p___s_t_r.html#aabe8b41f79403b6ac9936225ffd6d1a7',1,'BBUPOOL_CORE_OP_STR']]],
  ['avg_5fvalue',['AVG_VALUE',['../group__group__report.html#gga5ba119a4632109426940f4a9a8e72cbca031ae2dd4fefa897bbe2f97e342de7ca',1,'ebbu_pool_report.h']]]
];
