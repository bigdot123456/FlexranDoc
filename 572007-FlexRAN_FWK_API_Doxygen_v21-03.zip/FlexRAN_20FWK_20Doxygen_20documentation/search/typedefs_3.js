var searchData=
[
  ['multicellactivateinfor',['MultiCellActivateInfor',['../bbupool__common_8h.html#a5d0312a0a32b4d1fe6e1fb9e9dd379a8',1,'bbupool_common.h']]],
  ['multicelldectivateinfor',['MultiCellDectivateInfor',['../bbupool__common_8h.html#afb4427305e8afefe1b3f0a0c1b641167',1,'bbupool_common.h']]]
];
