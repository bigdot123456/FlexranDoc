var searchData=
[
  ['n_5fio_5fcore_5fnum',['N_IO_CORE_NUM',['../bbupool__macro_8h.html#a18bd42dbf5c89bf43c482c66646b843e',1,'bbupool_macro.h']]],
  ['n_5fmax_5fcell_5fper_5fbbu',['N_MAX_CELL_PER_BBU',['../bbupool__cfg_8h.html#a9faed16d0530f917d12f716fce337408',1,'bbupool_cfg.h']]],
  ['n_5fmax_5fcore_5fmasks',['N_MAX_CORE_MASKS',['../bbupool__macro_8h.html#ab38b29f162269778cf4ef7d75f4113c7',1,'bbupool_macro.h']]],
  ['n_5fmax_5fcore_5fnum_5fsupported',['N_MAX_CORE_NUM_SUPPORTED',['../bbupool__cfg_8h.html#a2f10a95634f431a571034b802decc3de',1,'bbupool_cfg.h']]],
  ['n_5fmax_5fcore_5fper_5fserver',['N_MAX_CORE_PER_SERVER',['../bbupool__macro_8h.html#a5c9d69bb25a27554b8fe2deb423b4093',1,'bbupool_macro.h']]],
  ['n_5fmax_5fgroup_5fper_5fbbu',['N_MAX_GROUP_PER_BBU',['../bbupool__macro_8h.html#ace5407b55b274f40ab2ddc091363c45a',1,'bbupool_macro.h']]],
  ['n_5fmax_5fqueue_5fnum',['N_MAX_QUEUE_NUM',['../bbupool__cfg_8h.html#adff9282ab96c68ac2fa1a33e10d93491',1,'bbupool_cfg.h']]],
  ['n_5fmax_5fsem_5fper_5fserver',['N_MAX_SEM_PER_SERVER',['../bbupool__macro_8h.html#aeab203dd9848566991882bd41df03edf',1,'bbupool_macro.h']]],
  ['n_5ftask_5ftype',['N_TASK_TYPE',['../bbupool__cfg_8h.html#a2e2744602990ac3b17a41d24328e2de8',1,'bbupool_cfg.h']]],
  ['num_5fof_5fsubframe_5fin_5fone_5fframe',['NUM_OF_SUBFRAME_IN_ONE_FRAME',['../bbupool__macro_8h.html#a094257b0fa4b38c872e48d50810c957d',1,'bbupool_macro.h']]]
];
