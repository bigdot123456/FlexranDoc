var searchData=
[
  ['sbbupoolconfiginfo',['sBbupoolConfigInfo',['../bbupool__common_8h.html#a2bb8138fe83cf7f358b714f8232f0f49',1,'bbupool_common.h']]],
  ['sconsumerctrl',['sConsumerCtrl',['../struct____attribute____.html#a30c3214012d338cfbbf0afea42b59ac1',1,'__attribute__']]],
  ['sconsumerstat',['sConsumerStat',['../struct____attribute____.html#a675f495064a4a727caf496bc20ef4ec4',1,'__attribute__']]],
  ['siocbconfig',['sIoCBConfig',['../bbupool__common_8h.html#a9b119d9c5ac42b16f03c541de778d0c4',1,'bbupool_common.h']]],
  ['sioportcbconfig',['sIoPortCBConfig',['../bbupool__common_8h.html#a9248aa02876e9531b2fbab728b0d0f48',1,'bbupool_common.h']]],
  ['siotaskcbconfig',['sIoTaskCBConfig',['../structs_io_task_c_b_config.html',1,'']]],
  ['siothreadcbconfig',['sIoThreadCBConfig',['../bbupool__common_8h.html#a3147afbf0eb4cf972dec453a5c63d0f0',1,'bbupool_common.h']]],
  ['splitidx',['splitIdx',['../structbbupool__task__gen__internal.html#a4738f9741c202d606a060b7dbcf038f2',1,'bbupool_task_gen_internal::splitIdx()'],['../structbbupool__rt__task__gen.html#aed6fa0e0adfa17833d2ae6ad52476192',1,'bbupool_rt_task_gen::splitIdx()'],['../structbbupool__rt__multitask__gen.html#a0c8dd2b82e4ce0d020ddd6f48a06bc59',1,'bbupool_rt_multitask_gen::splitIdx()'],['../bbupool__common_8h.html#a0ca411d030080b9019579a94892c0e92',1,'splitIdx():&#160;bbupool_common.h']]],
  ['splitnum',['splitNum',['../structbbupool__task__gen__internal.html#a0a549d1c84aaaa5d756038011b62eaac',1,'bbupool_task_gen_internal::splitNum()'],['../structbbupool__rt__task__gen.html#a34c837f5565dc9d4eb5cdeb2e4d2034a',1,'bbupool_rt_task_gen::splitNum()'],['../structbbupool__rt__multitask__gen.html#af76e016044225e4f47cf9ed02dd757fb',1,'bbupool_rt_multitask_gen::splitNum()'],['../bbupool__common_8h.html#a5917e58f979772534f55eefc3bfcbd3a',1,'splitNum():&#160;bbupool_common.h']]],
  ['splitvalid',['splitValid',['../structbbupool__task__gen__internal.html#a3578cbc1bc7fd9bce05dfd4cce22120b',1,'bbupool_task_gen_internal::splitValid()'],['../structbbupool__rt__task__gen.html#a1a15798e149cc56b6641992394b50f98',1,'bbupool_rt_task_gen::splitValid()'],['../structbbupool__rt__multitask__gen.html#ad4df1870821b26abaf674417b9b2b80b',1,'bbupool_rt_multitask_gen::splitValid()'],['../bbupool__common_8h.html#a40b5cabcb3c11d1629d92d2a44e95d3e',1,'splitValid():&#160;bbupool_common.h']]],
  ['statistic_5fall',['STATISTIC_ALL',['../group__group__report.html#gga5ba119a4632109426940f4a9a8e72cbca9e597b55612b3db4f126f06245d5e707',1,'ebbu_pool_report.h']]],
  ['statisticenum',['StatisticEnum',['../group__group__report.html#ga5ba119a4632109426940f4a9a8e72cbc',1,'ebbu_pool_report.h']]],
  ['sthreadconfig',['sThreadConfig',['../struct____attribute____.html#af00fe181b2d1fe74db3611ca92401d3b',1,'__attribute__']]],
  ['subframe',['subFrame',['../structbbupool__task__gen__internal.html#a697586f3e167e98218ed819bde74969b',1,'bbupool_task_gen_internal::subFrame()'],['../structbbupool__rt__task__gen.html#a98228347dc51bf0b0185760dcc22944b',1,'bbupool_rt_task_gen::subFrame()'],['../structbbupool__rt__multitask__gen.html#a8761b3f13f7a9b1deab206c09642270b',1,'bbupool_rt_multitask_gen::subFrame()'],['../bbupool__common_8h.html#a616ac2eb047cba9ac4e49e852dac198f',1,'subFrame():&#160;bbupool_common.h']]]
];
