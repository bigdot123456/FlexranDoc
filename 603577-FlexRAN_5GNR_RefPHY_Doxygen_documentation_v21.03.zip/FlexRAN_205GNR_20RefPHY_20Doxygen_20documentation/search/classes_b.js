var searchData=
[
  ['rballocatedstruct',['RBAllocatedStruct',['../struct_r_b_allocated_struct.html',1,'']]],
  ['rbgrantstruct',['RBGrantStruct',['../struct_r_b_grant_struct.html',1,'']]],
  ['redemapstruct',['REDemapStruct',['../struct_r_e_demap_struct.html',1,'']]],
  ['remapstruct',['REMapStruct',['../struct_r_e_map_struct.html',1,'']]],
  ['rou_5fbbu_5fpara_5ft',['rou_bbu_para_t',['../structrou__bbu__para__t.html',1,'']]],
  ['rte_5ft_5fop_5fldpc_5fdec',['rte_t_op_ldpc_dec',['../structrte__t__op__ldpc__dec.html',1,'']]]
];
