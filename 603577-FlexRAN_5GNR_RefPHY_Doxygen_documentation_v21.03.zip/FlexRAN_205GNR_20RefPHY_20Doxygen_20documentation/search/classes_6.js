var searchData=
[
  ['gnb_5febbupool_5fcore_5fusage_5fstats',['GNB_EBBUPOOL_CORE_USAGE_STATS',['../struct_g_n_b___e_b_b_u_p_o_o_l___c_o_r_e___u_s_a_g_e___s_t_a_t_s.html',1,'']]],
  ['gnb_5fio_5ffec_5fbbdev_5fstats',['GNB_IO_FEC_BBDEV_STATS',['../struct_g_n_b___i_o___f_e_c___b_b_d_e_v___s_t_a_t_s.html',1,'']]],
  ['gnb_5fpool_5fconfig',['GNB_POOL_CONFIG',['../struct_g_n_b___p_o_o_l___c_o_n_f_i_g.html',1,'']]]
];
