var searchData=
[
  ['xran_5fio_5fbuf_5fctrl',['xran_io_buf_ctrl',['../structxran__io__buf__ctrl.html',1,'']]],
  ['xran_5fio_5fshared_5fctrl',['xran_io_shared_ctrl',['../structxran__io__shared__ctrl.html',1,'']]],
  ['xran_5fstart_5fcfg',['xran_start_cfg',['../structxran__start__cfg.html',1,'']]],
  ['xransectionstruct',['xRANSectionStruct',['../structx_r_a_n_section_struct.html',1,'']]]
];
