var searchData=
[
  ['one_5fvf_5fcu_5fplane',['one_vf_cu_plane',['../structt_phy_cfg_vars.html#ad21f8cb6b2144eaae9ee7f72b33844a1',1,'tPhyCfgVars']]],
  ['op_5fflags',['op_flags',['../structt__op__ldpc__enc.html#ae21d944c29997c20293f403244ff41dc',1,'t_op_ldpc_enc::op_flags()'],['../structrte__t__op__ldpc__dec.html#ae21d944c29997c20293f403244ff41dc',1,'rte_t_op_ldpc_dec::op_flags()']]],
  ['opt_5floopback',['opt_loopback',['../structtag_frb_io_if_privat.html#ae4871bbee2fea2cb325e77656dcfccf7',1,'tagFrbIoIfPrivat']]]
];
