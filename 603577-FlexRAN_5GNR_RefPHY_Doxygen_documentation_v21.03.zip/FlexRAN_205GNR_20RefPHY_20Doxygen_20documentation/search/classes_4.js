var searchData=
[
  ['encodeinheaderstruct',['EncodeInHeaderStruct',['../struct_encode_in_header_struct.html',1,'']]],
  ['encodeoutheaderstruct',['EncodeOutHeaderStruct',['../struct_encode_out_header_struct.html',1,'']]]
];
