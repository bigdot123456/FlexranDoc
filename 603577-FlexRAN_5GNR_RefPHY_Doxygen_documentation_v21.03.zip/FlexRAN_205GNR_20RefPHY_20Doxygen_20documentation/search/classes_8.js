var searchData=
[
  ['lcore_5fqueue_5fconf',['lcore_queue_conf',['../structlcore__queue__conf.html',1,'']]],
  ['lcore_5fstats_5ftag',['lcore_stats_tag',['../structlcore__stats__tag.html',1,'']]]
];
