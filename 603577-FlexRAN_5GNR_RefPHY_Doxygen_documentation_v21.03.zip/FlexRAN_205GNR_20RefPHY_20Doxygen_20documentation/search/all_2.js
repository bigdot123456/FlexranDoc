var searchData=
[
  ['bad_5fqpsk_5fvec_5fh',['bad_qpsk_vec_h',['../canned__iq_8c.html#af315474c790d193cab064639a5d91de4',1,'bad_qpsk_vec_h():&#160;canned_iq.c'],['../canned__iq_8h.html#af315474c790d193cab064639a5d91de4',1,'bad_qpsk_vec_h():&#160;canned_iq.c']]],
  ['bad_5fqpsk_5fvec_5fl',['bad_qpsk_vec_l',['../canned__iq_8c.html#a4028b452a16fd94a81689c80575f38dd',1,'bad_qpsk_vec_l():&#160;canned_iq.c'],['../canned__iq_8h.html#a4028b452a16fd94a81689c80575f38dd',1,'bad_qpsk_vec_l():&#160;canned_iq.c']]],
  ['basegraph',['basegraph',['../structt__op__ldpc__enc.html#a8799e80594a3b681e8dbb709a56314db',1,'t_op_ldpc_enc::basegraph()'],['../structrte__t__op__ldpc__dec.html#a8799e80594a3b681e8dbb709a56314db',1,'rte_t_op_ldpc_dec::basegraph()']]],
  ['bbu_5fcore_5fremove',['BBU_CORE_REMOVE',['../gnb__l1__l2__api_8h.html#af08c70c5fcc7fabe9482c75ff5f7dfb9ae423c39e2573c68e89afe06c8d54859d',1,'gnb_l1_l2_api.h']]],
  ['bbu_5fcore_5fresume',['BBU_CORE_RESUME',['../gnb__l1__l2__api_8h.html#af08c70c5fcc7fabe9482c75ff5f7dfb9ac25a0b265f78303c6ba6830ab8949ea0',1,'gnb_l1_l2_api.h']]],
  ['bbu_5fcore_5fset_5fcore',['BBU_CORE_SET_CORE',['../gnb__l1__l2__api_8h.html#af08c70c5fcc7fabe9482c75ff5f7dfb9a3bc39a5607979205c3f215d16a577fa0',1,'gnb_l1_l2_api.h']]],
  ['bbu_5fcore_5fsuspend',['BBU_CORE_SUSPEND',['../gnb__l1__l2__api_8h.html#af08c70c5fcc7fabe9482c75ff5f7dfb9a395dcf3020e9737fc21c9bdbd9b89e8f',1,'gnb_l1_l2_api.h']]],
  ['bbu_5fdl_5fcompression',['bbu_dl_compression',['../structtag_f_h___i_o___i_f.html#a0a5bb7930f111140adb0dafa9a69f924',1,'tagFH_IO_IF']]],
  ['bbu_5fdl_5fiq',['bbu_dl_iq',['../structtag_f_h___i_o___i_f.html#a1237ef5a43fccac36d4699c810b952b3',1,'tagFH_IO_IF']]],
  ['bbu_5ful_5fiq',['bbu_ul_iq',['../structtag_f_h___i_o___i_f.html#a5a3951f30949f2e34d4d17ff9305a607',1,'tagFH_IO_IF']]],
  ['bbu_5fxran_5fio_5fif',['bbu_xran_io_if',['../structbbu__xran__io__if.html',1,'']]],
  ['bbufeioifstruct',['BbuFeIoIfStruct',['../struct_bbu_fe_io_if_struct.html',1,'']]],
  ['bbuiobufctrlstruct',['BbuIoBufCtrlStruct',['../struct_bbu_io_buf_ctrl_struct.html',1,'']]],
  ['bbupool_5fcore_5foperation',['BBUPOOL_CORE_OPERATION',['../gnb__l1__l2__api_8h.html#af08c70c5fcc7fabe9482c75ff5f7dfb9',1,'gnb_l1_l2_api.h']]],
  ['bbupoolcores',['bbuPoolCores',['../structtag_p_o_w_i_n_i_t.html#ac794cdf20db70bb7c26a137c27c854bc',1,'tagPOWINIT::bbuPoolCores()'],['../structtag_r_a_d_i_n_i_t.html#ac794cdf20db70bb7c26a137c27c854bc',1,'tagRADINIT::bbuPoolCores()']]],
  ['bchpayload',['BCHPayLoad',['../struct_b_c_h_pay_load.html',1,'']]],
  ['byte_5freverse',['byte_reverse',['../gnb__dl__phy__pbch_8c.html#a3bce50f126345b8287a0b0b9030445a1',1,'gnb_dl_phy_pbch.c']]],
  ['bbupool_20architecture',['BBUPool Architecture',['../ref_bbupool_architecture.html',1,'']]],
  ['bbupool_20tasks',['BBUPool Tasks',['../ref_bbupool_tasks.html',1,'']]],
  ['bit_20exact_20and_20wireless_20performance_20test_20cases',['Bit Exact and Wireless Performance Test Cases',['../ref_bit_exact_testing.html',1,'']]],
  ['bbdev_2drelated_20applications_20and_20tools',['BBDEV-related applications and tools',['../ref_testbbdev.html',1,'']]]
];
