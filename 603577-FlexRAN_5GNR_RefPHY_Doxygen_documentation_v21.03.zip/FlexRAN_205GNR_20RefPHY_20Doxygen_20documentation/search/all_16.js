var searchData=
[
  ['xran_5fio_5fbuf_5fctrl',['xran_io_buf_ctrl',['../structxran__io__buf__ctrl.html',1,'']]],
  ['xran_5fio_5fshared_5fctrl',['xran_io_shared_ctrl',['../structxran__io__shared__ctrl.html',1,'']]],
  ['xran_5fstart_5fcfg',['xran_start_cfg',['../structxran__start__cfg.html',1,'']]],
  ['xrannumdlprbs',['xRanNumDLPRBs',['../structt_phy_cfg_vars.html#ab17c5ed5fc1fa89fa69cb61ea7b1725f',1,'tPhyCfgVars']]],
  ['xrannumulprbs',['xRanNumULPRBs',['../structt_phy_cfg_vars.html#a28eb3d845fbbf10ffb7fa6387dd6c8a7',1,'tPhyCfgVars']]],
  ['xransectiondlconfigured',['xRANSectionDLConfigured',['../group__group__source__nr5g__api__mac2phy.html#ga4c5780356d70471b25a697fb593f6bf3',1,'gnb_mac2phy_api_proc_dl_config.c']]],
  ['xransectionstruct',['xRANSectionStruct',['../structx_r_a_n_section_struct.html',1,'']]]
];
